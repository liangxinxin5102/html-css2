<?php
/*
Plugin Name: Authentic Portfolio
Plugin URI: http://authenticthemes.com/plugins/
Description: Adds a portfolio post type to your site
Author: Authentic Themes
Author URI: http://authenticthemes.com
Version: 1.0
License: GNU General Public License version 3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/


//Include files
require_once( dirname(__FILE__) . '/register_post_type.php' );